# AI Soccer Frontend (MVP)
Simple HTML/JS client for uploading a video + attributes to the backend and rendering a report.

## Usage
- Host this (Replit "HTML/CSS/JS" or any static host).
- Make sure the backend is running, default is http://localhost:3000.
- Update `BACKEND` in the inline script if needed.
